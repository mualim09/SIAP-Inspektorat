<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
    //return redirect()->route('admin');
});
Auth::routes();
Route::post('/pic-update','ProfileController@profilePicUpdate')->name('pic.update');
Route::get('/get-profile','ProfileController@getData')->name('api.profile');
Route::get('/myprofile','ProfileController@edit')->name('myprofile');
Route::get('/admin/activity/useract','ProfileController@UserActivity')->name('useract');
Route::get('/admin/activity/bindex', 'ProfileController@viewActivity')->name('viewlog');
Route::get('/search-user', 'admin\UserController@search')->name('search_user');
Route::resource('/profile','ProfileController')->except('destroy');
Route::namespace('admin')->group(function () {
    // Controllers Within The "App\Http\Controllers\Admin" Namespace
    Route::get('/admin/users/getdata','UserController@getData');
	Route::get('/admin/roles/getdata','RoleController@getData');
	Route::get('/admin/permissions/getdata','PermissionController@getData');
	Route::get('/admin/jenis-spt/getdata','JenisSptController@getData');
	Route::get('/admin/spt/getdata','SptController@getData');
	Route::get('/admin/spt/get-anggota/{id}','SptController@getAnggota')->name('get_anggota_spt');
	Route::get('/admin/spt/cetak-pdf/{id}','SptController@sptPdf')->name('spt_pdf');
	Route::delete('/admin/spt/delete-anggota/{id}','SptController@deleteAnggota')->name('delete_anggota');
	Route::resource('/admin/roles','RoleController');
	Route::resource('/admin/permissions', 'PermissionController');
	Route::resource('/admin/users', 'UserController');
	Route::resource('/admin/jenis-spt', 'JenisSptController');
	Route::resource('/admin/spt', 'SptController');
});
Route::group(['middleware' => ['auth','permission:Access admin page']], function (){
	/*Route::get('/admin', function(){
		return view('admin.index');
	})->name('admin');*/
	Route::get('/spt/penomoran','admin\SptController@getPenomoranSpt')->name('get-penomoran');
	Route::get('/admin','admin\DashboardController@index')->name('admin');
	Route::get('/role-details/{id}', 'admin\RoleController@getMasterDetailsSingleData')->name('api.role_single_details');
	Route::get('/role-details', 'admin\RoleController@getMasterDetailsData')->name('api.role_details');
	Route::get('/cari-jenis-spt', 'admin\JenisSptController@cariJenisSpt')->name('api.cari_jenis_spt');
	Route::post('/insert-detail-spt','admin\SptController@storeDetail')->name('store_detail_spt');
	
});

Route::group(['middleware' => ['auth','permission:Edit Signed SPT']], function(){
	Route::post('spt/update-nomor','admin\SptController@updateNomorSpt')->name('update_nomor_spt');
});

Route::group(['middleware'=>['auth','permission:Sign SPT']], function(){
	Route::get('spt/get-processing-spt','admin\SptController@getProcessingSpt')->name('get-processing-spt');
	Route::post('spt/sign-reject', 'admin\SptController@signOrRejectSpt')->name('sign-reject-spt');
});
Route::group(['middleware' => ['auth']], function(){
	Route::get('spt/myspt','admin\SptController@mySpt')->name('my-spt');
});


//Route::get('/home', 'HomeController@index')->name('home');
/*Route::get('/admin/users/getdata','admin\UserController@getData');
Route::get('/admin/roles/getdata','admin\RoleController@getData');
Route::get('/admin/permissions/getdata','admin\PermissionController@getData');
Route::resource('/admin/roles','admin\RoleController');
Route::resource('/admin/permissions', 'admin\PermissionController');
Route::resource('/admin/users', 'admin\UserController');*/
